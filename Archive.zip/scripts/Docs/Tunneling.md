# Tunneling-Services.sh
- **Tunneling services are only needed for selfhosting or server hosting without a IPV4 ip address**
- Tunneling services are in the Settings of the Main menu. 

## LocalToNet 
- Linux and MacOS
- Fast but paid 
- Supports x64, ARM and ARM64 all in Either Glibc or Musl

## Playit.gg
- Linux Only
- Free but slow and Targeted by hackers.
- Offers premium options. 
- (Supports x64, i686, ARMv7 and ARM64 Glibc only)
- Also available as a MC plugin: https://modrinth.com/plugin/playit-companion

## Telebit.cloud
- Linux and MacOS
- Free, decently fast but only Java servers 
- Unknown Architectural limitations
- Autostart curently may not be working
