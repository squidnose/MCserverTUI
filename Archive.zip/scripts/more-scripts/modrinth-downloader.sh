#!/usr/bin/env bash
#============================ 0.1 MCserverTUI Config File ============================
MCSERVERTUI_CONF="$HOME/.local/state/MCserverTUI/MCserverTUI.conf"
if [ -f "$MCSERVERTUI_CONF" ]; then
    source "$MCSERVERTUI_CONF"
else
    echo "No MCserverTUI config file, please run MC-server-TUI.sh first!"
    exit 1
fi
#New parameters:
MC_ROOT="$mcdir"
## loggs (true or false)
## backups

#==================================== location ====================================
SCRIPT_DIR="$(dirname "$(realpath "$0")")"
## Detect terminal size
### in case tput is not found, sets to fixed value
TERM_HEIGHT=$(tput lines 2>/dev/null || echo 24)
TERM_WIDTH=$(tput cols 2>/dev/null || echo 80)
## Set TUI size based on terminal size
HEIGHT=$(( TERM_HEIGHT ))
WIDTH=$(( TERM_WIDTH ))
MENU_HEIGHT=$(( HEIGHT - 10 ))

#==================================== 0. Parse CLI flags ====================================
PASSED_NAME=""
while [[ "$#" -gt 0 ]]; do
    case "$1" in
        --name|-n)
            PASSED_NAME="$2"
            shift 2
            ;;
        *)
            echo "Unknown argument: $1"
            exit 1
            ;;
    esac
done

#==================================== 1. Select a server ====================================
if [ -n "$PASSED_NAME" ]; then
    # Bypass menu, validate directory
    SERVER_NAME="$PASSED_NAME"
    SERVER_DIR="$MC_ROOT/$SERVER_NAME"

    if [ ! -d "$SERVER_DIR" ]; then
        whiptail --title "Error" --msgbox "Server '$SERVER_NAME' does not exist!" "$HEIGHT" "$WIDTH"
        exit 0
    fi

else
    # Build menu items from directories
    MENU_ITEMS=()
    for d in "$MC_ROOT"/*; do
        [ -d "$d" ] || continue
        NAME=$(basename "$d")
        MENU_ITEMS+=("$NAME" "Minecraft server")
    done

    SERVER_NAME=$(whiptail --title "Choose Server" --menu "Select a server to manage:" "$HEIGHT" "$WIDTH" "$MENU_HEIGHT" \
        "${MENU_ITEMS[@]}" \
        3>&1 1>&2 2>&3) || exit 0

    SERVER_DIR="$MC_ROOT/$SERVER_NAME"
fi

#==================================== 2. Load config file ====================================
CONF_FILE="$SERVER_DIR/server-version.conf"

if [ -f "$CONF_FILE" ]; then
    source "$CONF_FILE"
else
    version=""
    loader=""
    collection=""
fi

#========================= 3. Ask for updated values (pre-filled) ==============================
MC_VERSION=$(whiptail --title "Minecraft Version" --inputbox \
    "Enter version:" "$HEIGHT" "$WIDTH" "$version" \
    3>&1 1>&2 2>&3) || exit 0

MC_LOADER=$(whiptail --title "Loader" --inputbox \
    "Enter loader, supported:\nforge, fabric, quilt, neoforge" "$HEIGHT" "$WIDTH" "$loader" \
    3>&1 1>&2 2>&3) || exit 0

MC_COLLECTION=$(whiptail --title "Collection" --inputbox \
    "Modrinth collection ID (optional):" "$HEIGHT" "$WIDTH" "$collection" \
    3>&1 1>&2 2>&3) || exit 0

#============================ 4. Save updated config ====================================
cat > "$CONF_FILE" <<EOF
version=$MC_VERSION
loader=$MC_LOADER
collection=$MC_COLLECTION
EOF

#==================================== 5. Run Downloader ====================================
if whiptail --title "Run Modrinth Downloader" --yesno \
    "Download mods using these settings?" "$HEIGHT" "$WIDTH"; then

    if [[ "$MC_LOADER" == "fabric" || \
          "$MC_LOADER" == "forge" || \
          "$MC_LOADER" == "neoforge" || \
          "$MC_LOADER" == "liteloader" || \
          "$MC_LOADER" == "quilt" || \
          "$MC_LOADER" == "rift" ]]; then

            # Build arguments dynamically
            ARGS=(-v "$MC_VERSION" -l "$MC_LOADER")
            [ -n "$MC_COLLECTION" ] && ARGS+=(-c "$MC_COLLECTION")

    elif [[ "$MC_LOADER" == "paper" || \
            "$MC_LOADER" == "purpur" || \
            "$MC_LOADER" == "folia" || \
            "$MC_LOADER" == "spigot" || \
            "$MC_LOADER" == "bukkit" || \
            "$MC_LOADER" == "sponge" || \
            "$MC_LOADER" == "velocity" ]]; then

            # Build arguments dynamically
            ARGS=(-v "$MC_VERSION" -l "$MC_LOADER" -d "./plugins")
            [ -n "$MC_COLLECTION" ] && ARGS+=(-c "$MC_COLLECTION")

    else
        whiptail --title "Error" --msgbox \
            "Unsupported loader: $MC_LOADER" "$HEIGHT" "$WIDTH"
        exit 0
    fi

    # Run Python *inside the server directory*
    (
        cd "$SERVER_DIR" || exit
        python3 "$SCRIPT_DIR/modrinth-autodownloader.py" "${ARGS[@]}"
        read -p "Press anything to continue"
    )
fi


whiptail --title "Done" --msgbox "Modrinth download complete for $SERVER_NAME!" "$HEIGHT" "$WIDTH"
exit 0
